import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, CalendarDays, Check,
  ChevronDown, Copy, Flower2, Heart, MapPin, Music2, Pause, Play,
  Share2, Sparkles, Volume2, VolumeX, X
} from 'lucide-react';
import { wedding } from './data/wedding.js';

const petals = Array.from({ length: 26 }, (_, index) => index);
const blessings = [
  'May your home always be filled with laughter.',
  'May every new morning bring you closer.',
  'May love and kindness light your journey.',
  'May the blessings of elders stay with you.'
];

function PetalField({ className = '' }) {
  return (
    <div className={`petal-field ${className}`} aria-hidden="true">
      {petals.map((petal) => (
        <i key={petal} className="floating-petal" style={{
          '--left': `${(petal * 37) % 100}%`,
          '--delay': `${(petal % 8) * -1.7}s`,
          '--duration': `${12 + (petal % 7) * 2}s`,
          '--size': `${7 + (petal % 4) * 3}px`,
          '--drift': `${((petal * 19) % 120) - 60}px`,
        }} />
      ))}
    </div>
  );
}

function Ornament({ className = '' }) {
  return <div className={`ornament ${className}`} aria-hidden="true"><span /><Flower2 size={20} strokeWidth={1.1} /><span /></div>;
}

function downloadEventCalendar(event) {
  const start = event.isoDate;
  if (!start) return;
  const [year, month, day] = start.split('-').map(Number);
  const next = new Date(Date.UTC(year, month - 1, day + 1));
  const dateForCalendar = (value) => value.toISOString().slice(0, 10).replaceAll('-', '');
  const escapeIcs = (value) => String(value || '').replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/;/g, '\\;').replace(/\n/g, '\\n');
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  const content = [
    'BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Ashish and Pushpanjali//Wedding Invitation//EN',
    'CALSCALE:GREGORIAN', 'BEGIN:VEVENT', `UID:${event.number}-${start}@ashish-pushpanjali-wedding`,
    `DTSTAMP:${stamp}`, `DTSTART;VALUE=DATE:${start.replaceAll('-', '')}`,
    `DTEND;VALUE=DATE:${dateForCalendar(next)}`,
    `SUMMARY:${escapeIcs(`${event.name} — Ashish & Pushpanjali`)}`,
    `LOCATION:${escapeIcs(event.venue)}`,
    `DESCRIPTION:${escapeIcs(`${event.name} celebration for Ashish Kumar Gupta and Pushpanjali Kumari, Darbhanga, Bihar.`)}`,
    'END:VEVENT', 'END:VCALENDAR',
  ].join('\r\n') + '\r\n';
  const file = new Blob([content], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(file);
  const link = document.createElement('a');
  link.href = url;
  link.download = `ashish-pushpanjali-${event.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.ics`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function Countdown({ compact = false }) {
  const target = useMemo(() => new Date(`${wedding.eventYear}-12-09T00:00:00+05:30`), []);
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  const remaining = Math.max(0, target.getTime() - now);
  const units = [
    ['DAYS', Math.floor(remaining / 86400000)],
    ['HOURS', Math.floor((remaining / 3600000) % 24)],
    ['MINUTES', Math.floor((remaining / 60000) % 60)],
    ['SECONDS', Math.floor((remaining / 1000) % 60)],
  ];
  return (
    <div className={`countdown ${compact ? 'countdown-compact' : ''}`} aria-label="Countdown to the wedding">
      <div className="countdown-heading"><span>{remaining > 0 ? 'THE BIG DAY IS APPROACHING' : 'THE CELEBRATION DAY IS HERE'}</span><Heart size={14} fill="currentColor" /></div>
      <div className="countdown-units">
        {units.map(([label, value], index) => <div className="countdown-unit" key={label} style={{ '--unit-index': index }}><strong>{String(value).padStart(2, '0')}</strong><small>{label}</small></div>)}
      </div>
    </div>
  );
}

function InvitationCover({ isOpening }) {
  return (
    <section className={`invitation-cover premium-entry ${isOpening ? 'is-opening' : ''}`} aria-label="Wedding invitation opening">
      <PetalField className="cover-petals" />
      <div className="premium-entry-glow premium-entry-glow-one" />
      <div className="premium-entry-glow premium-entry-glow-two" />
      <div className="premium-entry-layout">
        <div className="premium-entry-art">
          <img src={wedding.invitationCardImage} alt="Wedding invitation for Ashish Kumar Gupta and Pushpanjali Kumari" />
          <span className="premium-entry-art-caption">A CELEBRATION OF LOVE</span>
        </div>
        <div className="premium-entry-copy">
          <p className="premium-entry-mantra">॥ श्री गणेशाय नमः ॥</p>
          <span className="premium-entry-eyebrow">WITH THE BLESSINGS OF OUR FAMILIES</span>
          <h1><span>{wedding.groom.name}</span><em>&</em><span>{wedding.bride.name}</span></h1>
          <p className="premium-entry-hindi">{wedding.groom.hindi} <span>♥</span> {wedding.bride.hindi}</p>
          <div className="premium-entry-rule"><i />✦<i /></div>
          <p className="premium-entry-date">05 · 08 · 09 DECEMBER {wedding.eventYear}<small>DARBHANGA · BIHAR</small></p>
          <div className="premium-entry-loading"><span /><span /><span /></div>
          <small className="premium-entry-note">YOUR INVITATION IS OPENING</small>
        </div>
      </div>
      <div className="premium-entry-bottom">A JOYFUL BEGINNING · A LIFETIME OF BLESSINGS <span>✦</span></div>
    </section>
  );
}

function SectionKicker({ number, children, light = false, centered = false }) {
  return <div className={`section-kicker ${light ? 'light' : ''} ${centered ? 'centered' : ''}`}><span>{number}</span><i />{children}</div>;
}

function Hero({ onBlessing }) {
  const [hovered, setHovered] = useState(false);
  return (
    <section className={`hero hero-interactive ${hovered ? 'hero-hovered' : ''}`} id="home"
      onPointerMove={(event) => {
        const box = event.currentTarget.getBoundingClientRect();
        event.currentTarget.style.setProperty('--pointer-x', `${(event.clientX - box.left) / box.width * 100}%`);
        event.currentTarget.style.setProperty('--pointer-y', `${(event.clientY - box.top) / box.height * 100}%`);
      }} onPointerEnter={() => setHovered(true)} onPointerLeave={() => setHovered(false)}>
      <div className="hero-photo" /><div className="hero-shade" /><div className="hero-frame" />
      <PetalField className="hero-petals" />
      <div className="hero-content">
        <p className="eyebrow hero-eyebrow"><span /> A CELEBRATION OF LOVE <span /></p>
        <div className="hero-emblem"><Flower2 size={23} strokeWidth={1.1} /><span>शुभ विवाह</span><Flower2 size={23} strokeWidth={1.1} /></div>
        <p className="hero-intro-line">TWO HEARTS · TWO FAMILIES · ONE FOREVER</p>
        <h1 className="hero-couple-names"><span>{wedding.groom.name}</span><em>&</em><span>{wedding.bride.name}</span></h1>
        <p className="hero-hindi">{wedding.groom.hindi} <span>♥</span> {wedding.bride.hindi}</p>
        <Ornament className="hero-ornament" />
        <p className="hero-invite">With the blessings of our families,<br className="desktop-break" /> we invite you to celebrate our wedding.</p>
        <div className="hero-date-ribbon">
          <span><b>05</b><small>MATKOR</small></span><i />
          <span><b>08</b><small>HALDI</small></span><i />
          <span><b>09</b><small>WEDDING</small></span>
          <strong>DECEMBER {wedding.eventYear}</strong>
        </div>
        <div className="hero-action-row">
          <a href="#events" className="hero-button">VIEW CELEBRATIONS <ArrowDown size={15} /></a>
          <a href="#families" className="hero-secondary-button">MEET THE FAMILIES <ArrowUpRight size={15} /></a>
          <button type="button" className="hero-blessing-button" onClick={onBlessing}><Heart size={15} /> SEND A BLESSING</button>
        </div>
      </div>
      <div className="hero-side-note">DARBHANGA · BIHAR · INDIA</div>
      <div className="hero-bottom-label"><span /> SCROLL TO DISCOVER <span /></div>
      <div className="hero-pointer-glow" />
      <div className="hero-scroll-cue"><ChevronDown size={18}/></div>
    </section>
  );
}

function InvitationPreview() {
  const [zoom, setZoom] = useState(false);
  return (
    <section className="invitation-preview section-wrap" id="invitation">
      <div className="invitation-preview-copy" data-reveal>
        <SectionKicker number="01">THE WEDDING INVITATION</SectionKicker>
        <p className="hindi-line">श्री गणेशाय नमः</p>
        <h2>A little card.<br /><em>A lifetime of memories.</em></h2>
        <p className="invitation-preview-description">A sample digital invitation created for Ashish and Pushpanjali, with a Ganesh blessing and a traditional Mithila-inspired wedding mood.</p>
        <div className="invitation-preview-details"><span><b>०५</b> MATKOR PUJA</span><span><b>०८</b> HALDI & MEHNDI</span><span><b>०९</b> WEDDING</span></div>
        <div className="invitation-action-row">
          <button className="invitation-download" onClick={() => setZoom(true)}>VIEW INVITATION <ArrowUpRight size={15} /></button>
          <a className="invitation-download secondary" href={wedding.invitationCardImage} download="Ashish-Pushpanjali-Demo-Invitation.png"><ArrowDown size={15}/> SAVE CARD</a>
        </div>
        <p className="invitation-edit-note">Demo artwork — replace at <code>public/images/demo-invitation-card.png</code>.</p>
      </div>
      <figure className="invitation-preview-art" data-reveal>
        <button className="invitation-art-frame" onClick={() => setZoom(true)} aria-label="Open invitation card preview"><img src={wedding.invitationCardImage} alt="Sample wedding invitation card for Ashish Kumar Gupta and Pushpanjali Kumari" /><span className="image-view-hint">TAP TO VIEW <ArrowUpRight size={13}/></span></button>
        <figcaption><span>॥ श्री गणेशाय नमः ॥</span><span>A SAMPLE DIGITAL INVITATION</span></figcaption>
      </figure>
      {zoom && <ImageModal src={wedding.invitationCardImage} alt="Demo wedding invitation card" onClose={() => setZoom(false)} />}
    </section>
  );
}

function ImageModal({ src, alt, onClose, onNext, onPrevious, count }) {
  useEffect(() => {
    const onKey = (event) => { if (event.key === 'Escape') onClose(); if (event.key === 'ArrowRight') onNext?.(); if (event.key === 'ArrowLeft') onPrevious?.(); };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [onClose, onNext, onPrevious]);
  return (
    <div className="image-modal" role="dialog" aria-modal="true" aria-label={alt} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <button className="modal-close" onClick={onClose} aria-label="Close image"><X/></button>
      {onPrevious && <button className="modal-arrow modal-prev" onClick={onPrevious} aria-label="Previous image"><ArrowLeft/></button>}
      <img src={src} alt={alt}/>
      {onNext && <button className="modal-arrow modal-next" onClick={onNext} aria-label="Next image"><ArrowRight/></button>}
      {count && <span className="modal-count">{count}</span>}
    </div>
  );
}

function FamilyCard({ label, name, hindi, father, fatherHindi, mother, motherHindi, side, photo, photoAlt }) {
  const [expanded, setExpanded] = useState(false);
  const initial = name?.charAt(0) || '♥';
  return (
    <article className={`family-card ${side} family-card-interactive ${expanded ? 'family-expanded' : ''}`} data-reveal>
      <div className="family-card-top"><span>{label}</span><span className="tiny-flower">✿</span></div>
      <div className="family-photo-shell">
        <img src={photo} alt={photoAlt || `${label.toLowerCase()} portrait`} loading="lazy" onError={(event) => event.currentTarget.classList.add('photo-missing')} />
        <span className="family-photo-fallback" aria-hidden="true">{initial}</span>
        <span className="family-photo-caption">{label}</span>
      </div>
      <h3>{name}</h3><p className="family-hindi">{hindi}</p>
      <div className="family-divider"><span />✧<span /></div>
      <button type="button" className="family-expand-hint" onClick={() => setExpanded((value) => !value)} aria-expanded={expanded}>{expanded ? 'HIDE FAMILY DETAILS' : 'MEET THE FAMILY'} <ChevronDown size={14}/></button>
      <div className="family-parent-details">
        <div className="parent-detail"><small>FATHER</small><p>{father}</p><p className="parent-hindi">{fatherHindi}</p></div>
        <div className="parent-detail"><small>MOTHER</small><p>{mother}</p><p className="parent-hindi">{motherHindi}</p></div>
      </div>
    </article>
  );
}

function Intro() {
  return (
    <section className="intro section-wrap" id="families">
      <SectionKicker number="02">THE FAMILIES</SectionKicker>
      <div className="intro-heading" data-reveal>
        <p className="hindi-line">शुभारम्भ</p><h2>Two families.<br /><em>One beautiful beginning.</em></h2>
        <p className="section-copy">With immense joy and the blessings of our elders, we invite you to witness the beginning of a beautiful new journey.</p>
      </div>
      <div className="couple-intro-stage" data-reveal>
        <div className="couple-intro-backdrop" />
        <div className="couple-intro-copy">
          <span>THE BEGINNING OF FOREVER</span>
          <p>एक नया अध्याय · A NEW CHAPTER</p>
          <h3>Two souls, one beautiful story.</h3>
        </div>
      </div>
      <div className="family-grid">
        <FamilyCard label="THE BRIDE" name={wedding.bride.name} hindi={wedding.bride.hindi} father={wedding.bride.father} fatherHindi={wedding.bride.fatherHindi} mother={wedding.bride.mother} motherHindi={wedding.bride.motherHindi} side="bride" photo={wedding.bride.photo} photoAlt={wedding.bride.photoAlt} />
        <div className="family-heart" data-reveal><span><Heart size={20} fill="currentColor" /></span><small>बंधन</small><i>TOGETHER</i></div>
        <FamilyCard label="THE GROOM" name={wedding.groom.name} hindi={wedding.groom.hindi} father={wedding.groom.father} fatherHindi={wedding.groom.fatherHindi} mother={wedding.groom.mother} motherHindi={wedding.groom.motherHindi} side="groom" photo={wedding.groom.photo} photoAlt={wedding.groom.photoAlt} />
      </div>
      <div className="family-footnote" data-reveal><Ornament /><span>May the blessings of our parents and elders guide this new journey.</span><Ornament /></div>
    </section>
  );
}

function EventCard({ event }) {
  const [expanded, setExpanded] = useState(false);
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(event.searchVenue)}`;
  return (
    <article className={`event-card ${event.theme} event-card-interactive ${expanded ? 'event-expanded' : ''}`} data-reveal>
      <div className="event-index"><span>{event.number}</span><i>{event.icon}</i></div>
      <div className="event-main">
        <p className="event-date"><CalendarDays size={14} /> {event.date} <span>·</span> {wedding.eventYear}</p>
        <h3>{event.name}</h3><p className="event-hindi">{event.dateHindi} — {event.nameHindi}</p>
        <div className="event-venue"><MapPin size={16}/><div><small>VENUE / आयोजन स्थल</small><p>{event.venue}</p><p className="venue-hindi">{event.venueHindi}</p></div></div>
        <div className="event-actions">
          <div className="event-action-links">
            <a className="map-link" href={mapsUrl} target="_blank" rel="noreferrer">GET DIRECTIONS <ArrowUpRight size={15}/></a>
            <button className="calendar-link" type="button" onClick={() => downloadEventCalendar(event)}><CalendarDays size={14}/> ADD TO CALENDAR</button>
          </div>
          <button className="event-more" type="button" onClick={() => setExpanded((value) => !value)} aria-expanded={expanded}>{expanded ? 'LESS' : 'MORE'} <ChevronDown size={14}/></button>
        </div>
        {expanded && <div className="event-expanded-panel"><span>✦ A NOTE FOR OUR GUESTS</span><p>We look forward to celebrating this special occasion with you. Please join us at the venue listed above and bless the couple.</p><p className="event-hindi-note">आपकी उपस्थिति और आशीर्वाद हमारे लिए अनमोल हैं।</p></div>}
      </div>
      <div className="event-image-wrap"><img src={event.image} alt={event.imageAlt} loading="lazy" onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = '/images/wedding-placeholder.svg'; }}/><span className="event-photo-number">0{event.number}</span><span className="event-photo-caption">A MOMENT TO REMEMBER</span></div>
    </article>
  );
}

function Events() {
  return (
    <section className="events-section" id="events">
      <div className="events-texture"/><div className="section-wrap events-inner">
        <SectionKicker number="03" light>THE CELEBRATIONS</SectionKicker>
        <div className="events-title-row" data-reveal><div><p className="hindi-line">मंगल अवसर</p><h2>Three days.<br/><em>Countless memories.</em></h2></div><p className="events-intro">From traditional rituals to the wedding ceremony, every gathering is a celebration of family, culture and togetherness.</p></div>
        <div className="event-list">{wedding.events.map((event) => <EventCard key={event.number} event={event}/>)}</div>
        <Countdown/>
      </div>
    </section>
  );
}

function Gallery() {
  const [active, setActive] = useState(-1);
  const item = active >= 0 ? wedding.gallery[active] : null;
  const next = useCallback(() => setActive((value) => (value + 1) % wedding.gallery.length), []);
  const previous = useCallback(() => setActive((value) => (value - 1 + wedding.gallery.length) % wedding.gallery.length), []);
  return (
    <section className="gallery-section section-wrap" id="gallery">
      <SectionKicker number="04">A LITTLE INSPIRATION</SectionKicker>
      <div className="gallery-heading" data-reveal><div><p className="hindi-line">रंग, रस्में और रिश्ते</p><h2>Made of rituals.<br/><em>Wrapped in love.</em></h2></div><p>Inspired by the colours of Mithila, the joy of family gatherings and the beauty of Indian wedding traditions.</p></div>
      <div className="gallery-grid">
        {wedding.gallery.map((image, index) => (
          <button type="button" className={`gallery-item ${image.className}`} key={image.title} data-reveal onClick={() => setActive(index)} aria-label={`View ${image.title}`}>
            <img src={image.image} alt={image.alt} loading="lazy" onError={(e) => { e.currentTarget.onerror = null; e.currentTarget.src = '/images/wedding-placeholder.svg'; }}/><div className="gallery-veil"/>
            <span className="gallery-zoom"><ArrowUpRight size={17}/></span>
            <span className="gallery-caption"><span>0{index + 1}</span><span><strong>{image.title}</strong><small>{image.subtitle}</small></span></span>
          </button>
        ))}
      </div>
      <p className="gallery-note"><Sparkles size={14}/> Sample inspiration photos — replace these with your own wedding photographs in <code>src/data/wedding.js</code>.</p>
      {item && <ImageModal src={item.image} alt={item.alt} onClose={() => setActive(-1)} onNext={next} onPrevious={previous} count={`${active + 1} / ${wedding.gallery.length}`}/>}
    </section>
  );
}

function BlessingWall() {
  const [name, setName] = useState('');
  const [wish, setWish] = useState('');
  const [messages, setMessages] = useState(() => {
    try {
      const saved = window.localStorage.getItem('ashish-pushpanjali-wedding-blessings');
      const parsed = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed) ? parsed.slice(0, 12) : [];
    } catch { return []; }
  });
  const [copied, setCopied] = useState(false);
  function addWish(event) {
    event.preventDefault();
    if (!name.trim() || !wish.trim()) return;
    const message = { name: name.trim(), wish: wish.trim(), id: `${Date.now()}` };
    setMessages((current) => {
      const updated = [message, ...current].slice(0, 12);
      try { window.localStorage.setItem('ashish-pushpanjali-wedding-blessings', JSON.stringify(updated)); } catch { /* Storage may be unavailable in private browsing. */ }
      return updated;
    });
    setName(''); setWish('');
  }
  async function share() {
    const text = `Join us for the wedding of ${wedding.groom.name} & ${wedding.bride.name}, 9 December ${wedding.eventYear}, Darbhanga.`;
    try {
      if (navigator.share) await navigator.share({ title: 'Ashish & Pushpanjali Wedding', text, url: window.location.href });
      else { await navigator.clipboard.writeText(`${text} ${window.location.href}`); setCopied(true); window.setTimeout(() => setCopied(false), 1800); }
    } catch { /* User cancelled sharing. */ }
  }
  return (
    <section className="blessing-wall section-wrap" id="wishes">
      <div className="blessing-heading" data-reveal><SectionKicker number="05">A LITTLE LOVE FROM YOU</SectionKicker><p className="hindi-line">शुभाशीष</p><h2>Leave a little<br/><em>blessing behind.</em></h2><p>Write a wish for the couple. Your message appears here on this device as a demo.</p></div>
      <div className="blessing-layout">
        <form className="blessing-form" onSubmit={addWish} data-reveal>
          <label>Your name<input value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" maxLength={60} required/></label>
          <label>Your blessing<textarea value={wish} onChange={(e) => setWish(e.target.value)} placeholder="Write a few warm words for the couple…" maxLength={240} rows={4} required/></label>
          <button type="submit" className="submit-blessing">ADD YOUR BLESSING <Heart size={15}/></button>
          <button type="button" className="share-invitation" onClick={share}><Share2 size={15}/>{copied ? 'INVITATION LINK COPIED' : 'SHARE THE INVITATION'}</button>
          <small className="form-disclaimer">Your wishes are saved in this browser only; they are not sent to the family.</small>
        </form>
        <div className="blessing-messages" data-reveal>
          {messages.length === 0 ? <div className="empty-wish"><span>❧</span><strong>Your wishes will bloom here.</strong><small>Be the first to leave a blessing.</small></div> : messages.map((message) => <article className="wish-note" key={message.id}><span>“</span><p>{message.wish}</p><small>WITH LOVE, {message.name.toUpperCase()}</small></article>)}
        </div>
      </div>
    </section>
  );
}

function RSVP() {
  const [form, setForm] = useState({ name: '', attendance: 'Joyfully attending', guests: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const update = (key) => (e) => setForm((current) => ({ ...current, [key]: e.target.value }));
  function submit(event) {
    event.preventDefault();
    if (!form.name.trim() || (form.attendance === 'Joyfully attending' && !form.guests)) return;
    setSubmitted(true);
  }
  async function copyResponse() {
    const details = `Wedding RSVP\nName: ${form.name}\nAttendance: ${form.attendance}\nGuests: ${form.attendance === "Sorry, can't make it" ? '0' : (form.guests || 'Not sure')}\nMessage: ${form.message || '—'}`;
    try { await navigator.clipboard.writeText(details); setCopied(true); } catch { setCopied(false); }
  }
  return (
    <section className="rsvp-section" id="rsvp"><PetalField className="rsvp-petals"/><div className="rsvp-frame"/><div className="rsvp-content">
      <SectionKicker number="06" light centered>YOUR PRESENCE IS OUR PRESENT</SectionKicker><p className="hindi-line">सादर आमंत्रण</p><h2>Will you join<br/><em>our celebration?</em></h2><p className="rsvp-copy">Your blessings and good wishes mean the world to us. We would be delighted to celebrate together.</p>
      {submitted ? <div className="rsvp-success"><div><Check size={25}/></div><h3>Thank you, {form.name}!</h3><p>Your RSVP is ready. Copy it and share it with the family so they receive your response.</p><button type="button" className="rsvp-copy-button" onClick={copyResponse}><Copy size={14}/>{copied ? 'RSVP COPIED' : 'COPY RSVP DETAILS'}</button><button onClick={() => { setSubmitted(false); setCopied(false); }}>EDIT RESPONSE</button></div> : (
        <form className="rsvp-form" onSubmit={submit}>
          <label>Your name<input value={form.name} onChange={update('name')} placeholder="Enter your full name" required/></label>
          <div className="form-row"><label>Will you attend?<select value={form.attendance} onChange={update('attendance')}><option>Joyfully attending</option><option>Sorry, can't make it</option><option>Maybe</option></select></label><label>Number of guests<select value={form.guests} onChange={update('guests')} required={form.attendance === 'Joyfully attending'} disabled={form.attendance === "Sorry, can't make it"}><option value="" disabled>Select guest count</option><option value="1">1 guest</option><option value="2">2 guests</option><option value="3">3 guests</option><option value="4">4 guests</option><option value="5+">5+ guests</option></select></label></div>
          <label>A note for the couple<textarea value={form.message} onChange={update('message')} placeholder="Share your wishes (optional)" rows="3"/></label>
          <button className="submit-rsvp" type="submit">SEND YOUR RESPONSE <ArrowUpRight size={16}/></button><small className="form-disclaimer">Please select your guest count. This preview does not send responses to the family yet.</small>
        </form>
      )}
    </div></section>
  );
}

export default function App() {
  const [isOpening, setIsOpening] = useState(false);
  const [isOpened, setIsOpened] = useState(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [blessingIndex, setBlessingIndex] = useState(-1);
  const [showBlessing, setShowBlessing] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const audioRef = useRef(null);

  async function startMusic() {
    const audio = audioRef.current;
    if (!audio) return;
    try { await audio.play(); setIsMusicPlaying(true); }
    catch { setIsMusicPlaying(false); }
  }
  async function toggleMusic() {
    const audio = audioRef.current;
    if (!audio) return;
    if (isMusicPlaying) { audio.pause(); setIsMusicPlaying(false); }
    else await startMusic();
  }
  function openBlessing() {
    setBlessingIndex((value) => (value + 1) % blessings.length);
    setShowBlessing(true);
    document.getElementById('wishes')?.scrollIntoView({ behavior: 'smooth' });
  }

  // The invitation opens automatically; there is no Explore button or scratch gate.
  useEffect(() => {
    if (isOpening) return undefined;
    const autoOpen = window.setTimeout(() => setIsOpening(true), 1450);
    return () => window.clearTimeout(autoOpen);
  }, [isOpening]);

  useEffect(() => {
    if (!isOpening) return undefined;
    const timeout = window.setTimeout(() => setIsOpened(true), 950);
    return () => window.clearTimeout(timeout);
  }, [isOpening]);

  useEffect(() => {
    if (!isOpened) return;
    const audio = audioRef.current;
    if (audio) audio.play().catch(() => setIsMusicPlaying(false));
  }, [isOpened]);

  useEffect(() => {
    if (!isOpened) return undefined;
    const elements = document.querySelectorAll('[data-reveal]');
    if (!('IntersectionObserver' in window)) { elements.forEach((el) => el.classList.add('is-revealed')); return undefined; }
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) { entry.target.classList.add('is-revealed'); observer.unobserve(entry.target); }
    }), { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });
    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [isOpened]);

  useEffect(() => {
    if (!isOpened) return undefined;
    const update = () => {
      const max = document.documentElement.scrollHeight - window.innerHeight;
      setScrollProgress(max > 0 ? (window.scrollY / max) * 100 : 0);
      setShowTop(window.scrollY > 500);
    };
    update(); window.addEventListener('scroll', update, { passive: true });
    return () => window.removeEventListener('scroll', update);
  }, [isOpened]);

  return <>
    <audio ref={audioRef} src={wedding.backgroundMusic} loop preload="auto" onPause={() => setIsMusicPlaying(false)} onPlay={() => setIsMusicPlaying(true)}/>
    {!isOpened && <InvitationCover isOpening={isOpening}/>}
    <div className={`site-shell ${isOpened ? 'site-visible' : ''}`} aria-hidden={!isOpened}>
      <div className="scroll-progress" style={{ transform: `scaleX(${scrollProgress / 100})` }}/>
      <main><Hero onBlessing={openBlessing}/><InvitationPreview/><Intro/><Events/><Gallery/><BlessingWall/><RSVP/></main>
      {showBlessing && <div className="blessing-toast" role="status" onAnimationEnd={() => setShowBlessing(false)}><Sparkles size={16}/><span>{blessings[blessingIndex]}</span></div>}
      <div className="floating-controls">
        <button className={`music-toggle ${isMusicPlaying ? 'is-playing' : ''}`} onClick={toggleMusic} aria-label={isMusicPlaying ? 'Pause devotional music' : 'Play devotional music'} aria-pressed={isMusicPlaying} title={isMusicPlaying ? 'Pause music' : 'Play music'}>
          {isMusicPlaying ? <Pause size={17}/> : <Play size={17}/>}<span>{isMusicPlaying ? 'MUSIC ON' : 'MUSIC OFF'}</span>{isMusicPlaying && <i className="music-equalizer"><b/><b/><b/><b/></i>}
        </button>
        {showTop && <button className="back-to-top-float" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="Back to top"><ArrowUpRight size={17}/></button>}
      </div>
    </div>
  </>;
}
